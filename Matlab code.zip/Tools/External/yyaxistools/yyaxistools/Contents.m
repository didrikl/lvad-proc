% YYZOOM
%
% Files
%   yytick      - align ticks on both y-axes of a yyaxis plot with nice values
%   yyzoom      - allow zooming both y-axes of a yyaxis plot simultaneously
%   yyaxtoolbar - extended axes toolbar for yyaxis charts 






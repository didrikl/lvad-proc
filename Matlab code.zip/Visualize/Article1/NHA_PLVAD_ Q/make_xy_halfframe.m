function make_xy_halfframe(h_ax)
	set(h_ax,'box','off')
	set(h_ax,'XColor',[0.96,0.96,0.96])
	set(h_ax,'YColor',[0.96,0.96,0.96])
	set(h_ax,'XTickLabel',{})
	set(h_ax,'YTickLabel',{})
	set(h_ax,'TickLength',[0,0])
end
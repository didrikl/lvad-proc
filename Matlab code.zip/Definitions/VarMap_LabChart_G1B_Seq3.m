varMap = {
    % LabChart name  Matlab name   Type        Continuity
    %'SensorAAccX'    'accA_x'      'single'    'continuous'
    %'SensorAAccY'    'accA_y'      'single'    'continuous'
    %'SensorAAccZ'    'accA_z'      'single'    'continuous'
    'SensorBAccX'    'accB_x'      'single'    'continuous'
    'SensorBAccY'    'accB_y'      'single'    'continuous'
    'SensorBAccZ'    'accB_z'      'single'    'continuous'
    %'Trykk1'         'pGraft'      'single'    'continuous'
    };


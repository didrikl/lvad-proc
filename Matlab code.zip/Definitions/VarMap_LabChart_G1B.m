varMap = {
    % LabChart name  Matlab name   Type        Continuity
    %'SensorAAccX'    'accA_x'      'single'    'continuous'
    %'SensorAAccY'    'accA_y'      'single'    'continuous'
    %'SensorAAccZ'    'accA_z'      'single'    'continuous'
    'SensorBAccX'    'accB_x'      'single'    'continuous'
    'SensorBAccY'    'accB_y'      'single'    'continuous'
    'SensorBAccZ'    'accB_z'      'single'    'continuous'
    %'pGraft'         'pGraft'      'single'    'continuous'
	%'ECG'            'ecg'         'single'    'continuous'
    %'pMillarLV'      'pMillar'     'single'    'continuous'
	% 'V1'            'v1'          'single'    'continuous'
	% 'V2'            'v2'          'single'    'continuous'
	% 'V3'            'v3'          'single'    'continuous'
	% 'I1'            'i1'          'single'    'continuous'
	% 'I2'            'i2'          'single'    'continuous'
	% 'I3'            'i3'          'single'    'continuous'
    };

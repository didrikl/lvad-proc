%% Calculate and analyse features

% Manual assessment of specific intervention type segments
feats = make_feature_windows2(S, feats,'Balloon volume change'); 
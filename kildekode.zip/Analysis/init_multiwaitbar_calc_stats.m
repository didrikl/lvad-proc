function init_multiwaitbar_calc_stats

Colors_For_Processing
multiWaitbar('Making steady-state features',0,'Color',ColorsProcessing.Green);
multiWaitbar('Making spectral densities',0,'Color',ColorsProcessing.Green);
multiWaitbar('Making ROC matrix',0,'Color',ColorsProcessing.Green);
	
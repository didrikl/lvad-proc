Config.fs = 750;
Config.defFigRes = 300;
Config.experimentType = 'In vitro, model 2';
Config.experimentID = 'IV2';
Config.inletInnerDiamLVAD = 12.7;

Data.IV2.Config = Config;

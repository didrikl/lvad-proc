fprintf(['\nInit <strong>',Config.seq,'</strong> done.\n']);

clear PL US 
% clear S S_parts Notes

clear save_data

multiWaitbar('CloseAll');
close2 all;
clear hWait;

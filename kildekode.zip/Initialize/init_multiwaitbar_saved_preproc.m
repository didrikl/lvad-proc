function init_multiwaitbar_saved_preproc
	Colors_For_Processing
	multiWaitbar('Loading processed S files',0,'Color',ColorsProcessing.Green);
	multiWaitbar('Loading processed S_parts files',0,'Color',ColorsProcessing.Green,'CanCancel','on');